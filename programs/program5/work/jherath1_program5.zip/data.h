#ifndef DH_DATA_H
#define DH_DATA_H


/**
 *struct for Data
 **/
typedef struct Data{
   int value;
}Data;


#endif
